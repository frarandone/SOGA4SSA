The copyright holder for the various Stan licenses are listed
collectively as the Stan Development Team. The copyright for each code
contribution to Stan is held by its developer. Each contribution has
been licensed by its developer under the appropriate license:

   Stan:      new BSD
   Stan Math: new BSD
   CmdStan:   new BSD
   RStan:     GPLv3
   PyStan:    GPLv3

