theta <- 0.1
